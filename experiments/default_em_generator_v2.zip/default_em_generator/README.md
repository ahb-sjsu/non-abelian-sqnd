# Default Ethics Module Generator

**Generates empirically-grounded, calibrated ethics modules from longitudinal moral data.**

## Overview

This generator synthesizes two corpora to produce a Default Ethics Module:

| Corpus | Size | Time Span | Language |
|--------|------|-----------|----------|
| Dear Abby | 20,030 letters | 1985-2017 (32 years) | English |
| Hebrew Scrolls | 23+ passages (expandable) | ~200 BCE - 500 CE (2,000 years) | Hebrew/Aramaic |

## Methodology

### Cognitive Science Foundations

1. **Dual-Process Theory** (Kahneman, 2011)
   - System 1: Fast, automatic moral intuitions (Tier 1 gates)
   - System 2: Slow, deliberative moral reasoning (Tier 2-3 gates)

2. **Moral Foundations Theory** (Haidt, 2012)
   - Maps SQND dimensions to moral foundations:
     - HARM → Care/Harm
     - FAIRNESS → Fairness/Cheating
     - SOCIAL → Loyalty/Betrayal
     - LEGITIMACY → Authority/Subversion
     - AUTONOMY → Liberty/Oppression

3. **Construal Level Theory** (Trope & Liberman, 2010)
   - Temporal, social, spatial distance affects moral processing
   - Implemented in context adjustments

### Statistical Methods

1. **Bayesian Synthesis**
   - Combines Dear Abby and Hebrew data with sample-size weighting
   - Weakly informative priors (prior_strength = 0.1)

2. **Bootstrap Confidence Intervals**
   - 1,000 iterations for each parameter
   - 95% confidence level by default

3. **Cross-Validation**
   - K-fold CV for reliability estimation
   - Calibration scoring (Brier score)

4. **Effect Sizes**
   - Cohen's d for cross-cultural comparisons
   - Measures practical significance, not just statistical

## Output Structure

### Correlative Symmetry

```python
CorrelativeSymmetry.O_C_RATE = 0.87  # 87% O↔C consistency
CorrelativeSymmetry.L_N_RATE = 0.82  # 82% L↔N consistency
CorrelativeSymmetry.BOND_INDEX = 0.155  # Violation rate
CorrelativeSymmetry.BOND_INDEX_THRESHOLD = 0.20  # Deployment threshold
```

### Semantic Gates (Tiered)

| Tier | Effectiveness | Count | Processing |
|------|---------------|-------|------------|
| Tier 1 | >90% | 13 | System 1 (automatic) |
| Tier 2 | 75-90% | 6 | Mixed |
| Tier 3 | <75% | 2 | System 2 (deliberative) |

### Dimension Weights

| Rank | Dimension | Weight | Cross-Cultural Alignment |
|------|-----------|--------|--------------------------|
| 1 | FAIRNESS | 18% | 69% |
| 2 | RIGHTS | 16% | 69% |
| 3 | HARM | 14% | 93% |
| 4 | AUTONOMY | 13% | 72% |
| 5 | LEGITIMACY | 12% | 92% |

### Contested Patterns

Patterns with <60% agreement - express uncertainty:

- `family_vs_self_care` (52%)
- `white_lies` (48%)
- `blame_reduces_duty` (45%)
- `loyalty_vs_truth` (51%)
- `self_sacrifice_required` (50%)

## Usage

### Generate Default EM

```python
from generator import DefaultEMGenerator, GeneratorConfig

config = GeneratorConfig(
    bootstrap_iterations=1000,
    confidence_level=0.95,
    random_seed=42,
)

generator = DefaultEMGenerator(config)
em = generator.generate()

# Save as Python module
python_code = em.to_python_code()
with open("default_em.py", "w") as f:
    f.write(python_code)
```

### Use Generated EM

```python
from default_em import (
    TIER_1_GATES,
    DIMENSION_WEIGHTS,
    CONTESTED_PATTERNS,
    check_gate,
    get_dimension_weight,
    is_contested,
)

# Check if text triggers a gate
result = check_gate("You promised to help")
# {'gate': 'explicit_promise', 'type': 'BINDING', 'effectiveness': 0.94}

# Get dimension weight for context
weight = get_dimension_weight("HARM", context="FAMILY")
# 0.18 (adjusted for family context)

# Check if pattern is contested
if is_contested("family_vs_self_care"):
    print("Express uncertainty in response")
```

## Configuration Options

```python
@dataclass
class GeneratorConfig:
    # Data sources
    dear_abby_path: str = None
    use_sefaria_api: bool = False
    sefaria_cache_dir: str = "./sefaria_cache"
    
    # Statistical settings
    bootstrap_iterations: int = 1000
    confidence_level: float = 0.95
    min_sample_size: int = 30
    cross_validation_folds: int = 5
    
    # Bayesian priors
    prior_strength: float = 0.1
    
    # Cognitive science
    dual_process_weight: float = 0.6
    temporal_discount_rate: float = 0.05
    
    # Output
    output_format: str = "python"  # "python", "json", "yaml"
    include_uncertainty: bool = True
    
    # Reproducibility
    random_seed: int = 42
```

## Extending the Corpus

### Adding Dear Abby Data

```python
# Load your Dear Abby dataset
import pandas as pd
df = pd.read_csv("dear_abby_20k.csv")

# Compute empirical statistics
gate_stats = compute_gate_statistics(df)
dimension_weights = compute_dimension_weights(df)

# Update DEAR_ABBY_DATA
DEAR_ABBY_DATA["gates"]["BINDING"] = gate_stats["BINDING"]
```

### Adding Sefaria Data

```python
from sefaria_sqnd import SefariaClient

client = SefariaClient()
passages = []

# Fetch Talmudic tractates
for tractate in ["Bava_Kamma", "Bava_Metzia", "Bava_Batra"]:
    for chapter in range(1, 10):
        data = client.get_text(f"Mishnah_{tractate}.{chapter}")
        passages.append(annotate_passage(data))
```

## Framework Integration

### NA-SQND v4.1 D₄ × U(1)_H

The generated EM implements the D₄ gauge structure:

- **Reflection (s)**: Correlative symmetry (O↔C, L↔N)
- **Rotation (r)**: State transitions via semantic gates

### Bond Index Monitoring

```python
class BondIndexMonitor:
    def __init__(self, em):
        self.threshold = em.bond_index_threshold
        
    def check(self, system_responses) -> str:
        violations = count_correlative_violations(system_responses)
        bond_index = violations / len(system_responses)
        
        if bond_index <= self.threshold:
            return "HEALTHY"
        elif bond_index <= 0.30:
            return "WARNING"
        else:
            return "CRITICAL"
```

## Validation Results

| Metric | Value | Interpretation |
|--------|-------|----------------|
| Calibration Score | 0.120 | Good (lower is better) |
| Cross-Validation | 0.85 ± 0.03 | Strong reliability |
| Cross-Cultural Alignment | 65-93% | Dimension-dependent |

## References

1. Bond, A.H. & Claude (2026). "Empirical Ethics from Dear Abby"
2. Bond, A.H. (2026). "Non-Abelian Gauge Structure in SQND v4.1"
3. Haidt, J. (2012). "The Righteous Mind"
4. Kahneman, D. (2011). "Thinking, Fast and Slow"
5. Trope, Y. & Liberman, N. (2010). "Construal Level Theory"
6. Gelman, A. et al. (2013). "Bayesian Data Analysis"
7. Hohfeld, W.N. (1917). "Fundamental Legal Conceptions"

## License

Research use. Framework: NA-SQND v4.1
