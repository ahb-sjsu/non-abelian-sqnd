"""
Default Ethics Module Generator
===============================

Generates empirically-grounded, calibrated ethics modules by synthesizing:
- Dear Abby corpus (20,030 letters, 32 years)
- Hebrew Scrolls corpus (Sefaria API, 2,000 years)

Methodology:
- Cognitive Science: Dual-process theory, moral foundations
- Statistics: Bayesian inference, bootstrapping, cross-validation

Framework: NA-SQND v4.1 D₄ × U(1)_H

Usage:
    from default_em_generator import DefaultEMGenerator, GeneratorConfig
    
    config = GeneratorConfig(bootstrap_iterations=1000)
    generator = DefaultEMGenerator(config)
    em = generator.generate()
    
    # Save as Python module
    with open("default_em.py", "w") as f:
        f.write(em.to_python_code())
"""

from .generator import (
    # Main classes
    DefaultEMGenerator,
    GeneratorConfig,
    DefaultEM,
    
    # Data structures
    SemanticGate,
    DimensionWeight,
    ContestedPattern,
    CorrelativeStructure,
    HohfeldianState,
    
    # Cognitive science
    MoralFoundation,
    ProcessingMode,
    CognitiveContext,
    FOUNDATION_TO_DIMENSION,
    
    # Statistical utilities
    bootstrap_ci,
    cohens_d,
    bayesian_update,
    cross_validate,
    calibration_score,
    
    # Data sources
    DEAR_ABBY_DATA,
    HEBREW_DATA,
    
    # Code generation
    generate_python_code,
)

__version__ = "1.0.0"
__author__ = "SQND Research"
__framework__ = "NA-SQND v4.1 D₄ × U(1)_H"
