"""
Default Ethics Module - Auto-Generated
=======================================

Generated: 2026-01-10
Version: 1.0.0
Methodology: Bayesian synthesis: Dear Abby (32yr) + Hebrew Scrolls (2000yr)

Data Sources:
- Dear Abby: 20,030 letters
- Hebrew Scrolls: 23 passages
- Total: 20,053 observations

Framework: NA-SQND v4.1 D₄ × U(1)_H
"""

from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
from enum import Enum


# =============================================================================
# CORRELATIVE STRUCTURE
# =============================================================================

class CorrelativeSymmetry:
    """
    Hohfeldian correlative symmetry parameters.
    
    O↔C: 87.0% [85.0%, 89.2%]
    L↔N: 82.0% [79.6%, 84.4%]
    """
    
    O_C_RATE = 0.8700
    O_C_CI = (0.8498, 0.8919)
    
    L_N_RATE = 0.8200
    L_N_CI = (0.7958, 0.8438)
    
    BOND_INDEX = 0.1550
    BOND_INDEX_THRESHOLD = 0.2000


# =============================================================================
# SEMANTIC GATES
# =============================================================================

TIER_1_GATES = {
    # Near-universal gates (>85% effective)
    "oath": {
        "type": "BINDING",
        "triggers_en": ['oath', 'sworn'],
        "triggers_he": ['שבועה'],
        "effectiveness": 0.99,
        "ci": (0.89, 1.00),
    },
    "acquisition": {
        "type": "BINDING",
        "triggers_en": ['acquired', 'kinyan'],
        "triggers_he": ['קנין'],
        "effectiveness": 0.99,
        "ci": (0.89, 1.00),
    },
    "duress": {
        "type": "RELEASE",
        "triggers_en": ['duress', 'coerced', 'forced'],
        "triggers_he": ['אונס'],
        "effectiveness": 0.99,
        "ci": (0.89, 1.00),
    },
    "ones": {
        "type": "NULLIFY",
        "triggers_en": ['duress', 'impossibility'],
        "triggers_he": ['אונס'],
        "effectiveness": 0.99,
        "ci": (0.89, 1.00),
    },
    "impossible": {
        "type": "NULLIFY",
        "triggers_en": ['impossible'],
        "triggers_he": ['אי אפשר'],
        "effectiveness": 0.99,
        "ci": (0.89, 1.00),
    },
    "vow": {
        "type": "BINDING",
        "triggers_en": ['vow', 'vowed'],
        "triggers_he": ['נדר'],
        "effectiveness": 0.98,
        "ci": (0.88, 1.00),
    },
    "forgiveness": {
        "type": "RELEASE",
        "triggers_en": ['forgive', 'forgiven'],
        "triggers_he": ['מחילה'],
        "effectiveness": 0.95,
        "ci": (0.85, 1.00),
    },
    "abuse": {
        "type": "NULLIFY",
        "triggers_en": ['abusive', 'mistreated', 'harmful'],
        "effectiveness": 0.95,
        "ci": (0.90, 0.99),
    },
}

TIER_2_GATES = {
    # Strong gates (75-90% effective)
    "conditional": {
        "type": "RELEASE",
        "triggers_en": ['only if convenient', 'if you want', 'no pressure'],
        "effectiveness": 0.89,
    },
    "impossibility": {
        "type": "NULLIFY",
        "triggers_en": ['impossible', 'cannot', 'unable'],
        "effectiveness": 0.88,
    },
    "sole_recourse": {
        "type": "BINDING",
        "triggers_en": ['only one who can', 'no one else'],
        "effectiveness": 0.85,
    },
    "verbal_commitment": {
        "type": "BINDING",
        "triggers_en": ['said', 'spoke'],
        "effectiveness": 0.85,
    },
    "vulnerability": {
        "type": "BINDING",
        "triggers_en": ['elderly', 'disabled', 'vulnerable'],
        "effectiveness": 0.82,
    },
    "no_agreement": {
        "type": "RELEASE",
        "triggers_en": ['never agreed', "didn't promise", 'no commitment'],
        "effectiveness": 0.78,
    },
}

TIER_3_GATES = {
    # Contested gates (<75% effective) - express uncertainty
    "estrangement": {
        "type": "NULLIFY",
        "triggers_en": ['estranged', 'no contact', 'cut off'],
        "effectiveness": 0.72,
        "contested": True,
    },
    "significant_cost": {
        "type": "RELEASE",
        "triggers_en": ['at great cost', 'sacrifice', 'hardship'],
        "effectiveness": 0.55,
        "contested": True,
    },
}


# =============================================================================
# DIMENSION WEIGHTS
# =============================================================================

DIMENSION_WEIGHTS = {
    "FAIRNESS": {
        "weight": 0.1803,
        "ci": (0.1766, 0.1849),
        "cross_cultural_alignment": 0.69,
    },
    "RIGHTS": {
        "weight": 0.1598,
        "ci": (0.1561, 0.1645),
        "cross_cultural_alignment": 0.69,
    },
    "HARM": {
        "weight": 0.1399,
        "ci": (0.1362, 0.1445),
        "cross_cultural_alignment": 0.93,
    },
    "AUTONOMY": {
        "weight": 0.1301,
        "ci": (0.1265, 0.1348),
        "cross_cultural_alignment": 0.72,
    },
    "LEGITIMACY": {
        "weight": 0.1199,
        "ci": (0.1162, 0.1246),
        "cross_cultural_alignment": 0.92,
    },
    "SOCIAL": {
        "weight": 0.1000,
        "ci": (0.0964, 0.1047),
        "cross_cultural_alignment": 0.83,
    },
    "PRIVACY": {
        "weight": 0.0700,
        "ci": (0.0663, 0.0746),
        "cross_cultural_alignment": 0.50,
    },
    "PROCEDURE": {
        "weight": 0.0599,
        "ci": (0.0563, 0.0646),
        "cross_cultural_alignment": 0.83,
    },
    "EPISTEMIC": {
        "weight": 0.0400,
        "ci": (0.0367, 0.0448),
        "cross_cultural_alignment": 1.00,
    },
}


# =============================================================================
# CONTEXT ADJUSTMENTS
# =============================================================================

CONTEXT_ADJUSTMENTS = {
    "FAMILY": {
        "SOCIAL": 0.66,
        "HARM": 0.54,
        "FAIRNESS": 0.48000000000000004
    },
    "WORKPLACE": {
        "PROCEDURE": 0.6000000000000001,
        "FAIRNESS": 0.5700000000000001,
        "LEGITIMACY": 0.5100000000000001
    },
    "FRIENDSHIP": {
        "FAIRNESS": 0.66,
        "AUTONOMY": 0.54,
        "SOCIAL": 0.48000000000000004
    },
    "ROMANCE": {
        "AUTONOMY": 0.6000000000000001,
        "FAIRNESS": 0.54,
        "HARM": 0.48000000000000004
    },
    "NEIGHBORS": {
        "FAIRNESS": 0.72,
        "RIGHTS": 0.6000000000000001,
        "PRIVACY": 0.48000000000000004
    }
}


# =============================================================================
# CONTESTED PATTERNS
# =============================================================================

CONTESTED_PATTERNS = [
    {
        "name": "family_vs_self_care",
        "agreement_rate": 0.52,
        "ci": (0.47000000000000003, 0.5700000000000001),
        "cross_cultural_variance": 0.20,
    },
    {
        "name": "white_lies",
        "agreement_rate": 0.48,
        "ci": (0.43, 0.53),
        "cross_cultural_variance": 0.20,
    },
    {
        "name": "blame_reduces_duty",
        "agreement_rate": 0.45,
        "ci": (0.4, 0.5),
        "cross_cultural_variance": 0.20,
    },
    {
        "name": "loyalty_vs_truth",
        "agreement_rate": 0.51,
        "ci": (0.46, 0.56),
        "cross_cultural_variance": 0.20,
    },
    {
        "name": "self_sacrifice_required",
        "agreement_rate": 0.50,
        "ci": (0.4, 0.6),
        "cross_cultural_variance": 0.10,
    },
]


# =============================================================================
# COGNITIVE PARAMETERS
# =============================================================================

DUAL_PROCESS_WEIGHTS = {
    "system_1": 0.6190476190476191,
    "system_2": 0.38095238095238093
}

TEMPORAL_DISCOUNT_CURVE = [(0.0, 1.0), (0.1, 0.95), (0.3, 0.85), (0.5, 0.7), (0.7, 0.5), (1.0, 0.3)]


# =============================================================================
# DEPLOYMENT THRESHOLDS
# =============================================================================

BOND_INDEX_THRESHOLD = 0.2
CONFIDENCE_THRESHOLD_HIGH = 0.85
CONFIDENCE_THRESHOLD_CONTESTED = 0.6


# =============================================================================
# CALIBRATION METRICS
# =============================================================================

CALIBRATION_SCORE = 0.1199
CROSS_VALIDATION_SCORE = (0.8468020101364201, 0.03)


# =============================================================================
# USAGE EXAMPLE
# =============================================================================

def get_dimension_weight(dimension: str, context: str = None) -> float:
    """Get dimension weight, optionally adjusted for context."""
    base_weight = DIMENSION_WEIGHTS.get(dimension, {}).get("weight", 0.1)
    
    if context and context in CONTEXT_ADJUSTMENTS:
        adjustment = CONTEXT_ADJUSTMENTS[context].get(dimension, 1.0)
        return base_weight * adjustment
    
    return base_weight


def check_gate(text: str) -> Optional[dict]:
    """Check if text triggers any semantic gate."""
    text_lower = text.lower()
    
    for gate_name, gate_data in {**TIER_1_GATES, **TIER_2_GATES, **TIER_3_GATES}.items():
        for trigger in gate_data.get("triggers_en", []):
            if trigger.lower() in text_lower:
                return {
                    "gate": gate_name,
                    "type": gate_data["type"],
                    "effectiveness": gate_data["effectiveness"],
                    "contested": gate_data.get("contested", False),
                }
    
    return None


def is_contested(pattern_name: str) -> bool:
    """Check if a pattern is in the contested zone."""
    return any(p["name"] == pattern_name for p in CONTESTED_PATTERNS)


def get_confidence(pattern_name: str) -> float:
    """Get calibrated confidence for a pattern."""
    for p in CONTESTED_PATTERNS:
        if p["name"] == pattern_name:
            return p["agreement_rate"]
    
    # Not contested = high confidence
    return CONFIDENCE_THRESHOLD_HIGH
