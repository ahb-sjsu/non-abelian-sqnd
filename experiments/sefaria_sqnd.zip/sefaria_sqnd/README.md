# Sefaria SQND Analysis

Cross-temporal D₄ gauge structure analysis extending the Dear Abby baseline (32 years) to Hebrew Scrolls (2,000 years).

## Framework

**NA-SQND v4.1 D₄ × U(1)_H**

This package tests the hypothesis that the D₄ gauge structure underlying Hohfeldian normative positions is *fundamental* to human moral reasoning, not culturally contingent.

## Quick Start

```python
from sefaria_sqnd import run_analysis

# Run with cached sample data (no network required)
hebrew_analysis, comparison, report = run_analysis(use_sample=True)

# Run with live Sefaria API (requires network access to sefaria.org)
hebrew_analysis, comparison, report = run_analysis(use_sample=False)
```

## Output

The analysis produces:

1. **sqnd_cross_temporal_report.md** - Full markdown report comparing corpora
2. **hebrew_analysis.json** - Machine-readable analysis results

## Key Findings

### Invariant Patterns (appear in both 32-year and 2,000-year corpora)

- ✓ RELEASE gate exists in both (פטור/patur ↔ "exempt", מותר/mutar ↔ "permitted")
- ✓ BINDING gate exists in both (נדר/neder ↔ "vow", שבועה/shevuah ↔ "oath")
- ✓ NULLIFIER pattern exists in both (אונס/ones ↔ "duress", "abuse")
- ✓ O↔C correlative enforced in both
- ✓ L↔N correlative enforced in both

### Divergent Patterns (lexical variation, not structural)

- △ Hebrew has formal OATH category (שבועה) distinct from promise
- △ Hebrew has ACQUISITION (קנין/kinyan) as binding mechanism
- △ Dear Abby has informal "only if convenient" release gate
- △ Hebrew emphasizes CUSTOM (מנהג/minhag) as L-gate source

## Package Structure

```
sefaria_sqnd/
├── __init__.py              # Package exports
├── sefaria_client.py        # Sefaria API client + sample corpus
├── hebrew_hohfeldian.py     # D₄ pattern detector for Hebrew/English
└── cross_temporal_analysis.py  # Main comparison engine
```

## Hebrew Vocabulary for SQND

### Hohfeldian States

| State | Hebrew | Transliteration | Example |
|-------|--------|-----------------|---------|
| O (Obligation) | חייב | chayav | "חייב להחזיר" (obligated to return) |
| C (Claim) | זכות | zekhut | "יש לו זכות" (he has a right) |
| L (Liberty) | רשות | reshut | "מותר לו" (it is permitted to him) |
| N (No-claim) | אין זכות | ein zekhut | "אין לו לתבוע" (cannot demand) |

### Gate Triggers

| Gate | Hebrew Triggers | English Equivalents |
|------|-----------------|---------------------|
| O→L (Release) | פטור, מחל, הותר | exempt, forgive, release |
| L→O (Binding) | נדר, שבועה, התחייב | vow, oath, committed |
| →∅ (Nullify) | אונס, בטל, פסול | duress, void, invalid |

## Sefaria API

The package uses Sefaria's open API:
- Endpoint: `https://www.sefaria.org/api/v3/texts/{ref}`
- Rate limit: 60 requests/minute
- Documentation: https://developers.sefaria.org/

### Key Texts for SQND

1. **Ethics**: Pirkei Avot (Ethics of the Fathers)
2. **Civil Law**: Bava Kamma, Bava Metzia, Bava Batra (Talmud tractates on damages, property, commerce)
3. **Obligations**: Nedarim (Vows), Shevuot (Oaths)
4. **Family Law**: Kiddushin, Gittin, Ketubot
5. **Commentaries**: Rashi, Ramban, Sforno

## Extending the Analysis

### Adding More Texts

```python
from sefaria_sqnd import SefariaClient, SQNDCrossTemporalAnalyzer

client = SefariaClient()
analyzer = SQNDCrossTemporalAnalyzer()

# Fetch a specific text
passages = []
for i in range(1, 20):
    try:
        data = client.get_text(f"Mishnah_Bava_Kamma.{i}")
        passage = HebrewPassage.from_sefaria(data, "civil_law")
        passages.append(passage)
    except:
        break

# Analyze
analysis = analyzer.analyze_hebrew_corpus(passages)
```

### Adding Custom Gate Patterns

```python
from sefaria_sqnd import HebrewHohfeldianDetector, GATE_TRIGGERS

# Add a new release trigger
GATE_TRIGGERS["RELEASE"][r'\bexcused\b'] = ("excused", 0.85, "en")

detector = HebrewHohfeldianDetector()
# Detector now uses updated patterns
```

## Integration with EM-DAG

This package extends your existing EM-DAG system:

```python
from em_system import create_default_dag
from sefaria_sqnd import DEAR_ABBY_BASELINE, CorpusAnalysis

# Load Hebrew corpus analysis
with open("hebrew_analysis.json") as f:
    hebrew_data = json.load(f)

# The gate frequencies can calibrate EM module weights
# Hebrew shows higher binding-gate frequency for money domain
# → Increase MoneyEM module weight in EM-DAG
```

## Citation

```
Bond, A.H. (2026). Non-Abelian Gauge Structure in Stratified Quantum 
Normative Dynamics. NA-SQND v4.1.

Hebrew corpus analysis via Sefaria (https://www.sefaria.org/).
```

## License

Research use. Hebrew text content from Sefaria is under their open license.
