"""
Sefaria SQND Analysis Package
=============================

Cross-temporal D₄ gauge structure analysis comparing
Dear Abby (32 years) to Hebrew Scrolls (2,000 years).

Usage:
    from sefaria_sqnd import run_analysis
    
    hebrew_analysis, comparison, report = run_analysis(use_sample=True)
    
Components:
    - sefaria_client: API client for Sefaria.org
    - hebrew_hohfeldian: Pattern detector for Hebrew/English
    - cross_temporal_analysis: Main comparison engine
"""

from .sefaria_client import (
    SefariaClient,
    HebrewPassage,
    load_sample_corpus,
    fetch_sqnd_corpus,
    SQND_CORPUS,
    SAMPLE_PASSAGES
)

from .hebrew_hohfeldian import (
    HebrewHohfeldianDetector,
    HohfeldianState,
    GateType,
    GateDetection,
    HohfeldianMarker,
    HEBREW_PATTERNS,
    ENGLISH_PATTERNS,
    GATE_TRIGGERS
)

from .cross_temporal_analysis import (
    CorpusAnalysis,
    CrossTemporalComparison,
    SQNDCrossTemporalAnalyzer,
    DEAR_ABBY_BASELINE,
    run_analysis
)

__version__ = "1.0.0"
__author__ = "SQND Research"
__framework__ = "NA-SQND v4.1 D₄ × U(1)_H"
