"""
Hebrew Hohfeldian Pattern Detector
==================================

Extends the Dear Abby semantic gate detection to Hebrew legal/ethical texts.
Detects D₄ gauge structure markers in both Hebrew and English translations.

Key insight: If the D₄ structure is fundamental to human normative reasoning,
the same gate patterns should appear across 2,000 years of texts.
"""

import re
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Set
from enum import Enum
from collections import defaultdict


class HohfeldianState(Enum):
    """The four Hohfeldian positions"""
    O = "OBLIGATION"    # חייב (chayav) - Must do
    C = "CLAIM"         # זכות (zekhut) - Entitled to  
    L = "LIBERTY"       # רשות (reshut) - Free to choose
    N = "NO_CLAIM"      # אין זכות (ein zekhut) - Cannot demand


class GateType(Enum):
    """D₄ gate transitions"""
    RELEASE = "O→L"      # Obligation to Liberty
    BINDING = "L→O"      # Liberty to Obligation  
    FORFEIT = "C→N"      # Claim to No-claim
    ENTITLE = "N→C"      # No-claim to Claim
    NULLIFY = "→∅"       # Complete nullification


@dataclass
class GateDetection:
    """A detected semantic gate in text"""
    gate_type: GateType
    trigger_text: str           # The text that triggered detection
    trigger_pattern: str        # Pattern name
    context: str                # Surrounding text
    confidence: float           # 0-1 confidence
    language: str               # "he" or "en"
    position: Tuple[int, int]   # Start, end in original text
    metadata: Dict = field(default_factory=dict)


@dataclass
class HohfeldianMarker:
    """A detected Hohfeldian state marker"""
    state: HohfeldianState
    marker_text: str
    marker_pattern: str
    confidence: float
    language: str
    position: Tuple[int, int]


# =============================================================================
# HEBREW PATTERN VOCABULARY
# =============================================================================

# Hebrew roots and terms for Hohfeldian concepts
HEBREW_PATTERNS = {
    "OBLIGATION": {
        # חייב (chayav) - obligated, liable
        r'\bחייב\b': ("chayav", 0.95),
        r'\bחובה\b': ("chovah - duty", 0.95),
        r'\bמחויב\b': ("mechuyav - obligated", 0.95),
        r'\bצריך\b': ("tzarikh - must/need", 0.80),
        r'\bמצווה\b': ("mitzvah - commanded", 0.90),
        r'\bחיוב\b': ("chiyuv - obligation", 0.95),
        r'\bפטור\b': ("patur - exempt", 0.85),  # Note: indicates LACK of O
        r'\bאסור\b': ("assur - forbidden", 0.90),  # Negative O
    },
    "CLAIM": {
        # זכות (zekhut) - right, merit
        r'\bזכות\b': ("zekhut - right", 0.95),
        r'\bזכאי\b': ("zakai - entitled", 0.95),
        r'\bראוי\b': ("ra'ui - deserving", 0.75),
        r'\bבעל\b': ("ba'al - owner/master", 0.70),
        r'\bנושה\b': ("noseh - creditor", 0.85),
        r'\bתובע\b': ("tove'a - claimant", 0.90),
    },
    "LIBERTY": {
        # רשות (reshut) - permission, domain
        r'\bרשות\b': ("reshut - permission", 0.95),
        r'\bמותר\b': ("mutar - permitted", 0.95),
        r'\bרשאי\b': ("rashai - may", 0.95),
        r'\bיכול\b': ("yakhol - can/able", 0.70),
        r'\bהרשות בידו\b': ("ha-reshut beyado - it's in his hands", 0.95),
    },
    "NO_CLAIM": {
        # אין + claim terms
        r'\bאין ל\w+ זכות\b': ("ein lo zekhut - has no right", 0.95),
        r'\bאין ל\w+ רשות לתבוע\b': ("cannot demand", 0.90),
        r'\bאינו יכול לכופ\b': ("cannot compel", 0.95),
        r'\bאין כופין\b': ("ein kofin - we don't compel", 0.95),
    }
}

# English patterns (same as Dear Abby but extended for legal contexts)
ENGLISH_PATTERNS = {
    "OBLIGATION": {
        r'\bmust\b': ("must", 0.90),
        r'\bobligate[ds]?\b': ("obligated", 0.95),
        r'\brequired?\b': ("required", 0.90),
        r'\bshall\b': ("shall", 0.85),
        r'\bbound\b': ("bound", 0.85),
        r'\bliable\b': ("liable", 0.95),
        r'\bowe[sd]?\b': ("owed", 0.85),
        r'\bhave to\b': ("have to", 0.85),
        r'\bcommandment\b': ("commandment", 0.90),
        r'\bduty\b': ("duty", 0.90),
    },
    "CLAIM": {
        r'\bentitle[ds]?\b': ("entitled", 0.95),
        r'\bright to\b': ("right to", 0.95),
        r'\bclaim[s]?\b': ("claim", 0.85),
        r'\bcreditor\b': ("creditor", 0.90),
        r'\bdeserve[sd]?\b': ("deserves", 0.75),
        r'\bowed\b': ("owed", 0.85),
        r'\bdue\b': ("due", 0.80),
    },
    "LIBERTY": {
        r'\bmay\b': ("may", 0.80),
        r'\bpermit(ted)?\b': ("permitted", 0.95),
        r'\bfree to\b': ("free to", 0.90),
        r'\bchoose to\b': ("choose to", 0.75),
        r'\ballow(ed)?\b': ("allowed", 0.85),
        r'\bcan\b': ("can", 0.60),
        r'\bat liberty\b': ("at liberty", 0.95),
        r'\bvoluntary\b': ("voluntary", 0.85),
    },
    "NO_CLAIM": {
        r'\bcannot (demand|compel|force)\b': ("cannot compel", 0.95),
        r'\bno right to\b': ("no right to", 0.95),
        r'\bnot entitled\b': ("not entitled", 0.95),
        r'\bcannot claim\b': ("cannot claim", 0.90),
        r'\bno standing\b': ("no standing", 0.95),
    }
}

# Semantic gate triggers
GATE_TRIGGERS = {
    "RELEASE": {  # O→L
        # Hebrew
        r'\bפטור\b': ("patur - exempt", 0.95, "he"),
        r'\bמחל\b': ("machal - forgave", 0.90, "he"),
        r'\bהותר\b': ("hutar - released", 0.95, "he"),
        r'\bמתיר\b': ("matir - permits", 0.90, "he"),
        r'\bאונס\b': ("ones - duress", 0.95, "he"),  # Duress releases O
        # English
        r'\bexempt(ed)?\b': ("exempt", 0.95, "en"),
        r'\brelease[ds]?\b': ("released", 0.90, "en"),
        r'\bforgive[ns]?\b': ("forgiven", 0.85, "en"),
        r'\bwaive[ds]?\b': ("waived", 0.95, "en"),
        r'\bunder duress\b': ("under duress", 0.95, "en"),
        r'\bonly if convenient\b': ("only if convenient", 0.95, "en"),  # Dear Abby gate
        r'\bno longer\b': ("no longer", 0.70, "en"),
    },
    "BINDING": {  # L→O
        # Hebrew
        r'\bנדר\b': ("neder - vow", 0.95, "he"),
        r'\bשבועה\b': ("shevuah - oath", 0.95, "he"),
        r'\bקבל עליו\b': ("kibel alav - accepted upon himself", 0.95, "he"),
        r'\bהתחייב\b': ("hitchayev - obligated himself", 0.95, "he"),
        r'\bכרת ברית\b': ("karat brit - made covenant", 0.95, "he"),
        r'\bקנין\b': ("kinyan - acquisition", 0.90, "he"),
        # English  
        r'\bvow(ed)?\b': ("vowed", 0.95, "en"),
        r'\boath\b': ("oath", 0.95, "en"),
        r'\bpromise[ds]?\b': ("promised", 0.90, "en"),
        r'\bcommit(ted)?\b': ("committed", 0.85, "en"),
        r'\bcovenant\b': ("covenant", 0.95, "en"),
        r'\bbind(s|ing)?\b': ("binding", 0.90, "en"),
        r'\bcontract(ed)?\b': ("contracted", 0.90, "en"),
        r'\bagree[ds]?\b': ("agreed", 0.80, "en"),
    },
    "NULLIFY": {  # →∅ (Complete nullification)
        # Hebrew
        r'\bאונס\b': ("ones - duress/impossibility", 0.95, "he"),
        r'\bשוגג\b': ("shogeg - unintentional", 0.85, "he"),
        r'\bמוטעה\b': ("muta'eh - mistaken", 0.85, "he"),
        r'\bבטל\b': ("batel - void", 0.95, "he"),
        r'\bפסול\b': ("pasul - invalid", 0.95, "he"),
        r'\bטעות\b': ("ta'ut - error", 0.85, "he"),
        # English
        r'\bvoid\b': ("void", 0.95, "en"),
        r'\bnull(ified)?\b': ("null", 0.95, "en"),
        r'\bimpossible\b': ("impossible", 0.90, "en"),
        r'\billegal\b': ("illegal", 0.90, "en"),
        r'\bcoerced\b': ("coerced", 0.95, "en"),
        r'\binvalid\b': ("invalid", 0.90, "en"),
        r'\bunintentional\b': ("unintentional", 0.80, "en"),
        r'\bmistaken\b': ("mistaken", 0.80, "en"),
        r'\babuse[ds]?\b': ("abuse", 0.95, "en"),  # Dear Abby nullifier
    }
}


# =============================================================================
# DETECTOR CLASS
# =============================================================================

class HebrewHohfeldianDetector:
    """
    Detects Hohfeldian states and D₄ gate transitions in Hebrew/English texts.
    
    Usage:
        detector = HebrewHohfeldianDetector()
        markers, gates = detector.analyze(text_en, text_he)
    """
    
    def __init__(self):
        self.hebrew_patterns = HEBREW_PATTERNS
        self.english_patterns = ENGLISH_PATTERNS
        self.gate_triggers = GATE_TRIGGERS
        
    def detect_markers(self, text: str, language: str) -> List[HohfeldianMarker]:
        """Detect Hohfeldian state markers in text"""
        patterns = self.hebrew_patterns if language == "he" else self.english_patterns
        markers = []
        
        for state_name, state_patterns in patterns.items():
            state = HohfeldianState[state_name[0]]  # O, C, L, or N
            
            for pattern, (name, confidence) in state_patterns.items():
                for match in re.finditer(pattern, text, re.IGNORECASE):
                    markers.append(HohfeldianMarker(
                        state=state,
                        marker_text=match.group(),
                        marker_pattern=name,
                        confidence=confidence,
                        language=language,
                        position=(match.start(), match.end())
                    ))
                    
        return markers
    
    def detect_gates(self, text: str, language: str = None) -> List[GateDetection]:
        """Detect D₄ gate transitions in text"""
        gates = []
        
        for gate_name, gate_patterns in self.gate_triggers.items():
            gate_type = GateType[gate_name]
            
            for pattern, (name, confidence, lang) in gate_patterns.items():
                # Skip if language filter doesn't match
                if language and lang != language:
                    continue
                    
                for match in re.finditer(pattern, text, re.IGNORECASE):
                    # Get context (50 chars before/after)
                    start = max(0, match.start() - 50)
                    end = min(len(text), match.end() + 50)
                    context = text[start:end]
                    
                    gates.append(GateDetection(
                        gate_type=gate_type,
                        trigger_text=match.group(),
                        trigger_pattern=name,
                        context=context,
                        confidence=confidence,
                        language=lang,
                        position=(match.start(), match.end())
                    ))
                    
        return gates
    
    def analyze(self, english: str, hebrew: str = "") -> Dict[str, any]:
        """
        Full analysis of a passage.
        
        Returns:
            Dict with markers, gates, primary_state, and gate_summary
        """
        # Detect markers in both languages
        en_markers = self.detect_markers(english, "en") if english else []
        he_markers = self.detect_markers(hebrew, "he") if hebrew else []
        all_markers = en_markers + he_markers
        
        # Detect gates in both languages
        en_gates = self.detect_gates(english, "en") if english else []
        he_gates = self.detect_gates(hebrew, "he") if hebrew else []
        all_gates = en_gates + he_gates
        
        # Compute primary state (highest confidence)
        state_scores = defaultdict(float)
        for m in all_markers:
            state_scores[m.state] += m.confidence
            
        primary_state = max(state_scores, key=state_scores.get) if state_scores else None
        
        # Summarize gates
        gate_summary = defaultdict(int)
        for g in all_gates:
            gate_summary[g.gate_type.value] += 1
            
        return {
            "markers": all_markers,
            "gates": all_gates,
            "primary_state": primary_state,
            "state_scores": dict(state_scores),
            "gate_summary": dict(gate_summary),
            "has_nullifier": any(g.gate_type == GateType.NULLIFY for g in all_gates),
            "hebrew_markers": len(he_markers),
            "english_markers": len(en_markers),
        }
    
    def compare_languages(self, english: str, hebrew: str) -> Dict[str, any]:
        """
        Compare Hohfeldian structure between Hebrew and English.
        
        Tests hypothesis: If D₄ is fundamental, translations should
        preserve gate structure (modulo lexical differences).
        """
        en_analysis = self.analyze(english, "")
        he_analysis = self.analyze("", hebrew)
        combined = self.analyze(english, hebrew)
        
        # Check for structure preservation
        en_primary = en_analysis.get("primary_state")
        he_primary = he_analysis.get("primary_state")
        structure_preserved = en_primary == he_primary
        
        # Check gate alignment
        en_gates = set(en_analysis.get("gate_summary", {}).keys())
        he_gates = set(he_analysis.get("gate_summary", {}).keys())
        gate_alignment = len(en_gates & he_gates) / max(len(en_gates | he_gates), 1)
        
        return {
            "english_analysis": en_analysis,
            "hebrew_analysis": he_analysis,
            "combined_analysis": combined,
            "structure_preserved": structure_preserved,
            "gate_alignment": gate_alignment,
            "en_primary": en_primary,
            "he_primary": he_primary,
        }


def print_analysis_report(passage_ref: str, analysis: Dict):
    """Pretty print analysis results"""
    print(f"\n{'='*70}")
    print(f"📜 {passage_ref}")
    print('='*70)
    
    if analysis["primary_state"]:
        print(f"\n🎯 Primary State: {analysis['primary_state'].value}")
        
    if analysis["state_scores"]:
        print("\n📊 State Scores:")
        for state, score in sorted(analysis["state_scores"].items(), 
                                   key=lambda x: -x[1]):
            bar = "█" * int(score * 10)
            print(f"   {state.value:12} {bar} ({score:.2f})")
            
    if analysis["gates"]:
        print(f"\n⚙️  Gates Detected: {len(analysis['gates'])}")
        for g in analysis["gates"][:5]:
            print(f"   {g.gate_type.value:6} ← '{g.trigger_text}' ({g.trigger_pattern})")
            
    if analysis["has_nullifier"]:
        print("\n⚠️  NULLIFIER DETECTED - obligations may be void")
        
    print()


if __name__ == "__main__":
    try:
        from .sefaria_client import load_sample_corpus
    except ImportError:
        from sefaria_client import load_sample_corpus
    
    detector = HebrewHohfeldianDetector()
    corpus = load_sample_corpus()
    
    print("\n" + "="*70)
    print("Hebrew Hohfeldian Pattern Detection - SQND D₄ Analysis")
    print("="*70)
    
    for passage in corpus:
        analysis = detector.analyze(passage.english, passage.hebrew)
        print_analysis_report(passage.ref, analysis)
        
        # Show SQND note if present
        if passage.raw_data.get("sqnd_note"):
            print(f"   📝 SQND Note: {passage.raw_data['sqnd_note']}")
