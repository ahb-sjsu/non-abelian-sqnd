"""
Sefaria API Client for SQND Hebrew Text Analysis
================================================

Interfaces with Sefaria's open API to extract structured Jewish texts
for D₄ gauge structure measurement across 2,000 years of normative reasoning.

API Documentation: https://developers.sefaria.org/
Rate Limits: 60 requests/minute (be respectful)

SQND Framework: NA-SQND v4.1 D₄ × U(1)_H
"""

import requests
import json
import time
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple
from enum import Enum
from pathlib import Path
import re


# =============================================================================
# SEFARIA API CLIENT
# =============================================================================

class SefariaClient:
    """
    Client for Sefaria's REST API.
    
    Key endpoints for SQND analysis:
    - /api/v3/texts/{ref} - Get text content with translations
    - /api/search-wrapper/... - Search across corpus
    - /api/index/ - List all available texts
    """
    
    BASE_URL = "https://www.sefaria.org/api"
    V3_URL = "https://www.sefaria.org/api/v3"
    
    def __init__(self, cache_dir: str = "./sefaria_cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.request_count = 0
        self.last_request_time = 0
        
    def _rate_limit(self):
        """Respect 60 req/min limit"""
        now = time.time()
        if now - self.last_request_time < 1.0:
            time.sleep(1.0 - (now - self.last_request_time))
        self.last_request_time = time.time()
        self.request_count += 1
        
    def _get(self, url: str) -> Dict[str, Any]:
        """Make GET request with caching and rate limiting"""
        cache_key = url.replace("/", "_").replace(":", "_")
        cache_path = self.cache_dir / f"{cache_key}.json"
        
        # Check cache first
        if cache_path.exists():
            with open(cache_path) as f:
                return json.load(f)
        
        # Make request
        self._rate_limit()
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        
        # Cache response
        with open(cache_path, 'w') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            
        return data
    
    def get_text(self, ref: str, version: str = "all") -> Dict[str, Any]:
        """
        Get text content by reference.
        
        Args:
            ref: Sefaria reference (e.g., "Pirkei_Avot.1.1", "Mishnah_Bava_Metzia.4.1")
            version: Which versions to return ("all", "primary", specific version name)
            
        Returns:
            Dict with 'versions' containing Hebrew and English text
        """
        url = f"{self.V3_URL}/texts/{ref}"
        return self._get(url)
    
    def search(self, query: str, filters: Dict = None, limit: int = 100) -> List[Dict]:
        """
        Search across the Sefaria corpus.
        
        Args:
            query: Search terms
            filters: Category filters (e.g., {"categories": ["Talmud", "Mishnah"]})
            limit: Max results
            
        Returns:
            List of matching text segments
        """
        params = {
            "query": query,
            "size": limit,
            "type": "text"
        }
        if filters:
            params.update(filters)
            
        url = f"{self.BASE_URL}/search-wrapper/text/{query}"
        return self._get(url)
    
    def get_index(self) -> List[Dict]:
        """Get list of all available texts in Sefaria"""
        return self._get(f"{self.BASE_URL}/index/")
    
    def get_category_texts(self, category: str) -> List[str]:
        """Get all text references in a category"""
        index = self.get_index()
        refs = []
        
        def extract_refs(node, path=""):
            if isinstance(node, dict):
                if node.get("category") == category or category in path:
                    if "title" in node:
                        refs.append(node["title"])
                for key, value in node.items():
                    extract_refs(value, f"{path}/{key}")
            elif isinstance(node, list):
                for item in node:
                    extract_refs(item, path)
                    
        extract_refs(index)
        return refs


# =============================================================================
# SQND-RELEVANT SEFARIA SOURCES
# =============================================================================

# Key texts for Hohfeldian analysis
SQND_CORPUS = {
    "ethics": [
        # Ethics of the Fathers - foundational ethical maxims
        "Pirkei_Avot",
    ],
    "civil_law": [
        # Talmudic tractates on civil/commercial law (Hohfeldian goldmine)
        "Mishnah_Bava_Kamma",    # Damages, torts
        "Mishnah_Bava_Metzia",   # Found property, wages, bailment
        "Mishnah_Bava_Batra",    # Property rights, inheritance
        "Bava_Kamma",            # Talmud expansion
        "Bava_Metzia",
        "Bava_Batra",
    ],
    "obligations": [
        # Vows, oaths, and promises
        "Mishnah_Nedarim",       # Vows
        "Mishnah_Shevuot",       # Oaths
        "Nedarim",               # Talmud
        "Shevuot",
    ],
    "family_law": [
        # Marriage, divorce, inheritance
        "Mishnah_Kiddushin",     # Marriage
        "Mishnah_Gittin",        # Divorce
        "Mishnah_Ketubot",       # Marriage contracts
        "Mishnah_Yevamot",       # Levirate marriage
    ],
    "interpersonal": [
        # Ethics between people
        "Mishnah_Avot",          # Ethics
        "Mishnah_Sanhedrin",     # Courts, testimony
    ],
    "commentaries": [
        # Later commentaries with ethical reasoning
        "Rashi_on_Torah",
        "Ramban_on_Torah",
        "Sforno_on_Torah",
    ]
}

# Sample passages for testing (cached data when API unavailable)
SAMPLE_PASSAGES = [
    {
        "ref": "Pirkei_Avot.1.14",
        "he": "הוא היה אומר: אם אין אני לי, מי לי. וכשאני לעצמי, מה אני. ואם לא עכשיו, אימתי.",
        "en": "He used to say: If I am not for myself, who will be for me? And when I am only for myself, what am I? And if not now, when?",
        "source": "Hillel, 1st century BCE",
        "sqnd_note": "Liberty (L) grounded in self-obligation (O→self) with temporal gate"
    },
    {
        "ref": "Pirkei_Avot.2.4",
        "he": "הוא היה אומר: אל תדין את חברך עד שתגיע למקומו.",
        "en": "He used to say: Do not judge your fellow until you have reached his place.",
        "source": "Hillel, 1st century BCE",
        "sqnd_note": "Epistemic nullifier - judgment requires position-taking"
    },
    {
        "ref": "Bava_Metzia.75b.8",
        "he": "המלוה את חבירו לא ידור בחצרו חנם",
        "en": "One who lends money to another may not dwell in his courtyard rent-free.",
        "source": "Talmud, ~500 CE",
        "sqnd_note": "Reciprocity constraint: L(creditor, use property) → requires O(pay rent)"
    },
    {
        "ref": "Bava_Kamma.83b.1",
        "he": "עין תחת עין - ממון",
        "en": "An eye for an eye - [means] monetary compensation.",
        "source": "Talmud, ~500 CE",
        "sqnd_note": "Correlative transformation: C(victim, restitution) ↔ O(injurer, pay)"
    },
    {
        "ref": "Nedarim.27a.3",
        "he": "נדרי אונסים - מותרין",
        "en": "Vows made under duress are permitted [to be broken].",
        "source": "Talmud, ~500 CE",
        "sqnd_note": "DURESS nullifier: Coercion voids O-gate transition"
    },
    {
        "ref": "Mishnah_Bava_Metzia.6.1",
        "he": "השוכר את הפועלים ואמר להם להשכים ולהעריב, מקום שנהגו שלא להשכים ושלא להעריב, אינו יכול לכופן",
        "en": "One who hires workers and tells them to start early and work late - in a place where it is not customary to start early and work late, he cannot compel them.",
        "source": "Mishnah, ~200 CE",
        "sqnd_note": "Custom as L-gate: Local norms override employer's C"
    },
    {
        "ref": "Pirkei_Avot.5.13",
        "he": 'ארבע מדות באדם: האומר שלי שלי ושלך שלך, זו מדה בינונית... שלי שלך ושלך שלי, עם הארץ.',
        "en": "Four types of people: One who says 'What is mine is mine and what is yours is yours' - this is the average type... 'What is mine is yours and what is yours is mine' - this is an ignoramus.",
        "source": "Mishnah Avot, ~200 CE",
        "sqnd_note": "Property rights as L-baseline; confusion of O↔L = moral failure"
    },
    {
        "ref": "Shevuot.36a.4",
        "he": "אין נשבעין על הקרקעות",
        "en": "One does not take an oath regarding land.",
        "source": "Talmud, ~500 CE",
        "sqnd_note": "Domain-specific O-gate: Land claims exempt from oath-O"
    },
    {
        "ref": "Bava_Batra.12b.1",
        "he": "דינא דמלכותא דינא",
        "en": "The law of the kingdom is the law.",
        "source": "Samuel, Talmud ~300 CE",
        "sqnd_note": "Jurisdiction gate: Civil law creates valid O even if not halakhic"
    },
    {
        "ref": "Gittin.59b.2",
        "he": "מפני דרכי שלום",
        "en": "For the sake of the ways of peace.",
        "source": "Talmud, ~500 CE",
        "sqnd_note": "Peace as meta-principle: Can override strict O/C for social harmony"
    }
]


@dataclass
class HebrewPassage:
    """A passage from the Hebrew corpus"""
    ref: str                        # Sefaria reference
    hebrew: str                     # Original Hebrew
    english: str                    # English translation
    source_date: Optional[str]      # Approximate date
    category: str                   # ethics, civil_law, etc.
    raw_data: Dict = field(default_factory=dict)
    
    @classmethod
    def from_sefaria(cls, data: Dict, category: str = "unknown") -> "HebrewPassage":
        """Parse Sefaria API response into HebrewPassage"""
        versions = data.get("versions", [])
        
        hebrew = ""
        english = ""
        
        for v in versions:
            if v.get("language") == "he":
                hebrew = v.get("text", "")
            elif v.get("language") == "en":
                english = v.get("text", "")
                
        # Handle nested text structures
        if isinstance(hebrew, list):
            hebrew = " ".join(str(x) for x in hebrew if x)
        if isinstance(english, list):
            english = " ".join(str(x) for x in english if x)
            
        return cls(
            ref=data.get("ref", ""),
            hebrew=hebrew,
            english=english,
            source_date=None,
            category=category,
            raw_data=data
        )
    
    @classmethod
    def from_sample(cls, sample: Dict) -> "HebrewPassage":
        """Create from cached sample data"""
        return cls(
            ref=sample["ref"],
            hebrew=sample["he"],
            english=sample["en"],
            source_date=sample.get("source"),
            category="sample",
            raw_data=sample
        )


def load_sample_corpus() -> List[HebrewPassage]:
    """Load the cached sample passages for testing"""
    return [HebrewPassage.from_sample(s) for s in SAMPLE_PASSAGES]


def fetch_sqnd_corpus(client: SefariaClient, 
                      categories: List[str] = None,
                      limit_per_text: int = 50) -> List[HebrewPassage]:
    """
    Fetch the SQND-relevant corpus from Sefaria.
    
    Args:
        client: SefariaClient instance
        categories: Which categories to fetch (default: all)
        limit_per_text: Max passages per text
        
    Returns:
        List of HebrewPassage objects
    """
    if categories is None:
        categories = list(SQND_CORPUS.keys())
    
    passages = []
    
    for cat in categories:
        texts = SQND_CORPUS.get(cat, [])
        for text_name in texts:
            try:
                # Get first N passages
                for i in range(1, limit_per_text + 1):
                    ref = f"{text_name}.{i}"
                    try:
                        data = client.get_text(ref)
                        passage = HebrewPassage.from_sefaria(data, cat)
                        if passage.english or passage.hebrew:
                            passages.append(passage)
                    except Exception as e:
                        # Stop when we hit invalid refs
                        break
            except Exception as e:
                print(f"Error fetching {text_name}: {e}")
                
    return passages


if __name__ == "__main__":
    # Demo with sample data
    print("Loading sample Hebrew corpus for SQND analysis...")
    corpus = load_sample_corpus()
    
    print(f"\nLoaded {len(corpus)} passages\n")
    print("=" * 70)
    
    for p in corpus[:5]:
        print(f"\n📜 {p.ref}")
        print(f"   Hebrew: {p.hebrew[:60]}...")
        print(f"   English: {p.english[:80]}...")
        if p.raw_data.get("sqnd_note"):
            print(f"   SQND: {p.raw_data['sqnd_note']}")
